﻿using kursyKonwerter.ViewModels;

namespace kursyKonwerter
{
    public partial class MainPage : ContentPage
    {
        public MainPage(OddConverterViewModel vm)
        {
            InitializeComponent();
            BindingContext = vm;
        }



    }
}
