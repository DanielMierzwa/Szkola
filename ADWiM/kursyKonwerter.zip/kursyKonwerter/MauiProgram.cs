﻿using CommunityToolkit.Maui;
using kursyKonwerter.ViewModels;
using Microsoft.Extensions.Logging;

namespace kursyKonwerter
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder.UseMauiApp<App>().UseMauiCommunityToolkit();

#if DEBUG
    		builder.Logging.AddDebug();


#endif

            builder.Services.AddTransient<OddConverterViewModel>();

            builder.Services.AddTransient<MainPage>();
            return builder.Build();
        }
    }
}
