﻿using System;
using System.Collections.Generic;
using System.Text;

namespace kursyKonwerter.Models
{
    public static class Calculator
    {
        private static int GreatestCommonDivisor(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return Math.Abs(a);
        }
        private static int nwd(int x,int y)
        {

            while (x != y)
            {

                if (x > y)
                    x = x - y;
                else
                    y = y - x;
            }

            return x;
        }
        public static double SharesToProbability(double shares)
        {
            return shares / 100.0;
        }

        public static double ProbabilityToShares(double probability)
        {
            return probability * 100.0;
        }
        public static double AmericanOddsToProbability(double americanOdds)
        {
            if (americanOdds < 0)
                return -americanOdds / (-americanOdds + 100);
            else
                return 100/(americanOdds + 100);
        }
        public static double ProbabilityToAmericanOdds(double probability) 
        {
            if (probability < 0.5)
                return 100 * (1 - probability) / probability;
            else 
                return -100 * probability / (1 - probability);
        }

        public static double FractionalOddsToProbability(int nominator, int denominator) 
        {
            return (double)denominator/(double)(nominator+denominator);
        }

        public static (int Numerator, int Denominator) ProbabilityToFractionalOdds(double probability)
        {
            var decimalOdds = Math.Round(ProbabilityToDecimalOdds(probability),2);
            var fractional = decimalOdds-1.0;
            // Aproksymacja ułamka do najbliższej liczby całkowitej
            const int PRECISION = 1000; // Im większa, tym wynik będzie dokładniejszy

            var numerator = (int)Math.Round(fractional * PRECISION,2);
            var denominator = PRECISION;

            // Skracanie ułamka
            var gcd = GreatestCommonDivisor(numerator, denominator);
            return ((int)(numerator / gcd), (int)(denominator / gcd));
        }
        public static double DecimalOddsToProbability(double decimalOdd)
        {
            return 1.0 / decimalOdd;
        }
        public static double ProbabilityToDecimalOdds(double probability)

        {
            return 1.0 / probability;
        }
    }
}
