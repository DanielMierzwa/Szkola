﻿using System;
using System.Collections.Generic;
using System.Text;

namespace kursyKonwerter.Models
{
    public enum OddsNotation
    {
        Fractional, American, Decimal, Share
    }
}
