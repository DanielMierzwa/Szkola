﻿//using CommunityToolkit.Mvvm.ComponentModel;
//using System;
//using System.Collections.Generic;
//using System.Text;

//namespace kursyKonwerter.ViewModels
//{
//    public partial class OddConverterViewModel : ObservableObject
//    {
//        [ObservableProperty]
//        public string payout = "20";

//        [ObservableProperty]
//        public string win = "20";

//        [ObservableProperty]
//        public string convertedOdds = "20";

//        [ObservableProperty]
//        public float odds;

//        [ObservableProperty]
//        public int size;

//        private float probability;

//        partial void OnOddsChanged(float value)
//        {
//            float converted = 1 / Odds;
//            ConvertedOdds = converted.ToString() + "C";
//        }

//    }
//}
using CommunityToolkit.Mvvm.ComponentModel;
using kursyKonwerter.Models;

namespace kursyKonwerter.ViewModels
{
    public partial class OddConverterViewModel : ObservableObject
    {
        [ObservableProperty]
        private string odds;

        [ObservableProperty]
        private string size;

        [ObservableProperty]
        private OddsNotation inputNotation = OddsNotation.Decimal;

        [ObservableProperty]
        private OddsNotation outputNotation = OddsNotation.Fractional;

        private bool _isUpdating;

        partial void OnOddsChanged(string value)
        {
            if (_isUpdating)
                return;
            var text = Odds ?? string.Empty;

            string filtered = FilterFractionInput(text);

            if (filtered != text)
            {
                _isUpdating = true;
                Odds = filtered;
                _isUpdating = false;
            }
        }

        private string FilterFractionInput(string input)
        {
            if (string.IsNullOrEmpty(input))
                return string.Empty;

            var result = new System.Text.StringBuilder();

            bool specialUsed = false;

            foreach (char c in input)
            {
                if (char.IsDigit(c))
                {
                    result.Append(c);
                }
                else if (c == ',' && !specialUsed)
                {
                    result.Append(c);
                    specialUsed = true;
                }
                else if (c == '/' && !specialUsed)
                {
                    result.Append(c);
                    specialUsed = true;
                }
            }

            return result.ToString();
        }
    }

}