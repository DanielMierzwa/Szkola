﻿using kursyKonwerter.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace kursyKonwerter.Converters
{
    public class OddsValueConverter : OddsConverterBase, IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if(values.Length == 3 
                && values[0] is OddsNotation input
                && values[1] is OddsNotation output
                && values[2] is string oddsText)
            {
                try
                {
                    var probability = ConvertToProbability(oddsText, input);
                    return ConvertToOutput(probability, output);
                }
                catch
                {
                    return "-";
                }
            }
            return "-";
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
