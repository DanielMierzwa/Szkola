﻿using kursyKonwerter.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace kursyKonwerter.Converters
{
    public class RadioButtonConverter : IValueConverter
    {
        public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            if(value is OddsNotation && parameter is string)
            {
                OddsNotation oddsNotation = (OddsNotation)value;
                return oddsNotation.ToString()==parameter.ToString();
            }
            return false;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool && parameter is string )
            {
                bool isChecked = (bool)value;
                if(isChecked)
                {
                    string target = parameter.ToString();
                    return Enum.Parse(typeof(OddsNotation), target);
                }
            }

            return null;
        }
    }
}
