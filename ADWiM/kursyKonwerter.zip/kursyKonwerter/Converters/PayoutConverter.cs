﻿using kursyKonwerter.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace kursyKonwerter.Converters
{
    public class PayoutConverter : OddsConverterBase, IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            try
            {
                // Dobrze jest się zabezpieczyć, na wypadek źle podanych parametrów w XAML
                if (values.Length == 3 && values[0] is OddsNotation inputNotation && values[1] is string oddsText && values[2] is string sizeText && parameter is string outputType && !String.IsNullOrEmpty(outputType))
                {
                    // Żeby nie tworzyć zbyt wielu konwerterów, można sobie uprościć zabawę poprzez sparametryzowanie takiego konwertera.
                    double probability = ConvertToProbability(oddsText, inputNotation);
                    string decimalOddsString = ConvertToOutput(probability, OddsNotation.Decimal);
                    if (!double.TryParse(decimalOddsString, out double decimalOdds))
                        return "-";
                    if (!double.TryParse(sizeText, out var size))
                        return "-";
                    double payout = decimalOdds * size;
                    if (outputType == "Payout")
                    {

                        return Math.Round(payout, 2).ToString("$0.00");

                    }
                    else if (outputType == "Win")
                    {
                        double win = payout - size;
                        return Math.Round(win, 2).ToString("$0.00");
                    }

                    // Czy tutaj może zostać rzucony wyjątek?
                }
            }
            catch (Exception e)
            {
                return 0;
            }
                // Zwracamy wartość, informującą użytkownika, że operacja się nie udała.
                return "-";
        }

        // Nie potrzebujemy obsługi konwersji w drugą stronę, więc zostawiamy NotImplementedException.
        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
