﻿using System;
using System.Collections.Generic;
using System.Text;
using kursyKonwerter.Models;

namespace kursyKonwerter.Converters
{
    public abstract class OddsConverterBase
    {
        protected double ConvertToProbability(string inputOdds, OddsNotation inputNotation)
        {
            try
            {
                // Tutaj przyjmujemy input jako string, nasz kalkulator potrzebuje double oraz nie obsługuje enuma OddsNotation.
                // Uznajmy więc, że jest to metoda pomocnicza, która pomaga nam przekształcić każdy typ kursu na prawdopodobieństwo.
                if (inputNotation == OddsNotation.Fractional)
                {
                    var parts = inputOdds.Split('/');
                    if (parts.Length != 2)
                        throw new ArgumentException("Invalid fractional odds format."); // <-- zapobiegamy błędnym wynikom.
                    
                    try
                    {
                        int numerator, denominator;
                        numerator = int.Parse(parts[0]);
                        denominator = int.Parse(parts[1]);
                        return Calculator.FractionalOddsToProbability(numerator, denominator);
                    }
                    catch (Exception e)
                    {
                        return 0;
                    }

                }

                // Kiedy przekonwertujemy nasz kurs na liczbę, możemy bez problemu odwołać się do kalkulatora.
                var odds = Double.Parse(inputOdds);
                switch (inputNotation)
                {
                    case OddsNotation.Decimal:
                        return Calculator.DecimalOddsToProbability(odds);
                        break;
                    case OddsNotation.American:
                        return Calculator.AmericanOddsToProbability(odds);
                        break;
                    case OddsNotation.Share:
                        return Calculator.SharesToProbability(odds);
                        break;

                }
                ;
                return 0;
            }
            catch (Exception e)
            {
                return 0;
            }
        }

        protected string ConvertToOutput(double probability, OddsNotation outputNotation)
        {
            if (probability == 0)
                return "-";
            // Tutaj próbujemy zwrócić końcową wartość jako string - już po formatowaniu.
            switch (outputNotation)
            {
                case OddsNotation.American:
                    return Math.Round(Calculator.ProbabilityToAmericanOdds(probability), 1).ToString("+0.##;-0.##");
                    break;
                case OddsNotation.Fractional:
                    (int numerator, int denumerator) = Calculator.ProbabilityToFractionalOdds(probability);
                    return numerator.ToString() + "/" + denumerator.ToString();
                    break;
                case OddsNotation.Decimal:
                    return Math.Round(Calculator.ProbabilityToDecimalOdds(probability), 1).ToString("0.00");
                    break;
                case OddsNotation.Share:
                    return Math.Round(probability,2).ToString("0.00¢");
                    break;
                default:
                    return "[Error]";
            }

            // Jeżeli tutaj doszliśmy, coś poszło nie tak. Co powinniśmy więc zwrócić? A może rzucić?
        }
    }
}
